# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
NinetyNineCats::Application.config.secret_token = '23599bbee7a05f07ca053f2f3af5af472a23a808d0881198abefda731c6424a02f59e7b02baf1cc73bf6690b735b7f3ffd71925053642285be7537cd3541a7b6'
